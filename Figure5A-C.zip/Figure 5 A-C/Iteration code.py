# -*- coding: mbcs -*-

# This program is an iteration program for parameters optimization.
# When use this program, one has to modify the working directory, CAE filename, 'Model' name, 'Step' name,
# 'Variables' name and etc., which are shown in Green color as below. 
# To run this program, one has to have one CAE file in the same directory.

# Created by: Wenlong Li
# Time: 6-14-2019
# modify @ 7-5-2019

from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from abaqus import *
from abaqusConstants import *
from odbAccess import *
from abaqusConstants import *
from odbMaterial import *
from odbSection import *
import numpy as np 

# Load the module
mdb.openAuxMdb(pathName='Pavement_cell_3rd_remesh.cae')
mdb.copyAuxMdbModel(fromName='Model-10_remesh_p6_003base', toName='Model-10_remesh_p6_003base')
mdb.closeAuxMdb()

def runABAQUS(jobname,E_o,Turgor,E_i_ratio,maxh):
    poissonratio = 0.47
    G = 2.0*E_o
    bulk = 2.0*G*(1.0+poissonratio)/3.0/(1.0-2.0*poissonratio)
    D1 = 2.0/bulk
# Assign these parameters to the module
    mdb.models['Model-10_remesh_p6_003base'].materials['ANTICLINAL-UNIFORM'].viscoelastic.setValues(
        domain=TIME, table=((E_i_ratio, 0.0, 6.88), ), time=PRONY)
    mdb.models['Model-10_remesh_p6_003base'].materials['ANTICLINAL-UNIFORM'].hyperelastic.setValues(
        table=((E_o, D1), ))
    mdb.models['Model-10_remesh_p6_003base'].loads['Load-3'].setValues(magnitude=Turgor)
# 5.85 um is the distance between the probe and the initial contact area 5.85 P6; P4 6.01; P3 6.5; P1 6.6
# 5.95 P5; P2;: 6.45 P7: 6.5; P8:6.7; p9 = 6.6; p10 = 6.72
# 0.6 um is a compensation distance to ensure the tip contact slightly with the sample
    BC_disp = -(5.35-maxh)
    mdb.models['Model-10_remesh_p6_003base'].boundaryConditions['BC-step1'].setValues(u3=BC_disp)
# creat a job
    mdb.Job(atTime=None, contactPrint=OFF, description='', echoPrint=OFF, 
        explicitPrecision=SINGLE, getMemoryFromAnalysis=True, historyPrint=OFF, 
        memory=90, memoryUnits=PERCENTAGE, model='Model-10_remesh_p6_003base', 
        modelPrint=OFF, multiprocessingMode=DEFAULT, name=jobname,
        nodalOutputPrecision=SINGLE, numCpus=5, numDomains=5, numGPUs=0, queue=None
        , resultsFormat=ODB, scratch='', type=ANALYSIS, userSubroutine='',
        waitHours=0, waitMinutes=0)
# submit a job and wait until completion
    mdb.jobs[jobname].submit(consistencyChecking=OFF)
    mdb.jobs[jobname].waitForCompletion()
# -*- END runABAQUS() -*-

# read odb and return F vs. dip. and Max. height.
def extractForcDisp(jobname):
    pathname = jobname + '.odb'
    odb = openOdb(path=pathname)
    probe = odb.rootAssembly.instances['CONICALPROBE_SOLID_SMOOTH-1'].nodeSets['SET-10']
    dispforc150 = odb.steps['Step-unload120nm'].frames
    dispforc1540 = odb.steps['Step-unload1500nm'].frames
    
    dispforc240 = odb.steps['Step-unload240nm'].frames
    dispforc360 = odb.steps['Step-unload360nm'].frames
    dispforc970 = odb.steps['Step-unload970nm'].frames
    dispforc1240 = odb.steps['Step-unload1240nm'].frames
    
    dispment150Value = []
    dispment1540Value = []

    dispment240Value = []
    dispment360Value = []
    dispment970Value = []
    dispment1240Value = []

    force150Value = []
    force1540Value = []

    force240Value = []
    force360Value = []
    force970Value = []
    force1240Value = []
    
# read disp of the probe
    for d150 in dispforc150 :
        UT3value = d150.fieldOutputs['UT'].getSubset(region=probe).values[-1].data[2]
        dispment150Value.append(UT3value)
    for d1540 in dispforc1540 :
        UT3value = d1540.fieldOutputs['UT'].getSubset(region=probe).values[-1].data[2]
        dispment1540Value.append(UT3value)
	
    for d240 in dispforc240 :
        UT3value = d240.fieldOutputs['UT'].getSubset(region=probe).values[-1].data[2]
        dispment240Value.append(UT3value)
    for d360 in dispforc360 :
        UT3value = d360.fieldOutputs['UT'].getSubset(region=probe).values[-1].data[2]
        dispment360Value.append(UT3value)
    for d970 in dispforc970 :
        UT3value = d970.fieldOutputs['UT'].getSubset(region=probe).values[-1].data[2]
        dispment970Value.append(UT3value)
    for d1240 in dispforc1240 :
        UT3value = d1240.fieldOutputs['UT'].getSubset(region=probe).values[-1].data[2]
        dispment1240Value.append(UT3value)
# read contact force      
    step1 = odb.steps['Step-unload120nm']
    region = step1.historyRegions['NodeSet  Z000001']
    fData = region.historyOutputs['CFN3     ASSEMBLY_UPPERLAYER_003BASE-1_SURF-CONTACT/ASSEMBLY_CONICALPROBE_SOLID_SMOOTH-1_SURF-CONTACTINDENTER'].data
    for f in fData:
        force150Value.append(f[1])
    step2 = odb.steps['Step-unload1500nm']
    region = step2.historyRegions['NodeSet  Z000001']
    fData = region.historyOutputs['CFN3     ASSEMBLY_UPPERLAYER_003BASE-1_SURF-CONTACT/ASSEMBLY_CONICALPROBE_SOLID_SMOOTH-1_SURF-CONTACTINDENTER'].data
    for f in fData:
        force1540Value.append(f[1])
		
    step3 = odb.steps['Step-unload240nm']
    region = step3.historyRegions['NodeSet  Z000001']
    fData = region.historyOutputs['CFN3     ASSEMBLY_UPPERLAYER_003BASE-1_SURF-CONTACT/ASSEMBLY_CONICALPROBE_SOLID_SMOOTH-1_SURF-CONTACTINDENTER'].data
    for f in fData:
        force240Value.append(f[1])
    step4 = odb.steps['Step-unload360nm']
    region = step4.historyRegions['NodeSet  Z000001']
    fData = region.historyOutputs['CFN3     ASSEMBLY_UPPERLAYER_003BASE-1_SURF-CONTACT/ASSEMBLY_CONICALPROBE_SOLID_SMOOTH-1_SURF-CONTACTINDENTER'].data
    for f in fData:
        force360Value.append(f[1])
    step5 = odb.steps['Step-unload970nm']
    region = step5.historyRegions['NodeSet  Z000001']
    fData = region.historyOutputs['CFN3     ASSEMBLY_UPPERLAYER_003BASE-1_SURF-CONTACT/ASSEMBLY_CONICALPROBE_SOLID_SMOOTH-1_SURF-CONTACTINDENTER'].data
    for f in fData:
        force970Value.append(f[1])
    step6 = odb.steps['Step-unload1240nm']
    region = step6.historyRegions['NodeSet  Z000001']
    fData = region.historyOutputs['CFN3     ASSEMBLY_UPPERLAYER_003BASE-1_SURF-CONTACT/ASSEMBLY_CONICALPROBE_SOLID_SMOOTH-1_SURF-CONTACTINDENTER'].data
    for f in fData:
        force1240Value.append(f[1])
# read Max. disp (height)
# P1=51293; P2=43795; P3=49503; P4=50179; P5=44685; P6=40378; P7=53568; P8=44826; P9=45097; P10=49704; MAX = 54106; p6flat=51200
    maxnode = odb.rootAssembly.instances['UPPERLAYER_003BASE-1'].getNodeFromLabel(43795)
    maxheight = odb.steps['Step-1addpressure'].frames[-1].fieldOutputs['UT'].getSubset(region=maxnode).values[-1].data[2]

    disp150 = np.array(dispment150Value)
    force150 = np.array(force150Value)
    slope = np.polyfit(disp150, force150,1)
    slope150 = slope[0]

    disp1540 = np.array(dispment1540Value)
    force1540 = np.array(force1540Value)
    slope = np.polyfit(disp1540, force1540,1)
    slope1540 = slope[0]
	
    disp240 = np.array(dispment240Value)
    force240 = np.array(force240Value)
    slope = np.polyfit(disp240, force240,1)
    slope240 = slope[0]
	
    disp360 = np.array(dispment360Value)
    force360 = np.array(force360Value)
    slope = np.polyfit(disp360, force360,1)
    slope360 = slope[0]
	
    disp970 = np.array(dispment970Value)
    force970 = np.array(force970Value)
    slope = np.polyfit(disp970, force970,1)
    slope970 = slope[0]
	
    disp1240 = np.array(dispment1240Value)
    force1240 = np.array(force1240Value)
    slope = np.polyfit(disp1240, force1240,1)
    slope1240 = slope[0]

    slope150  = abs(slope150)
    slope1540 = abs(slope1540)	
	
    slope240 = abs(slope240)
    slope360 = abs(slope360)
    slope970 = abs(slope970)
    slope1240 = abs(slope1240)
    return slope150,slope1540,maxheight,slope240,slope360,slope970,slope1240
    odb.close()
# -*- END extractForcDisp() -*-

# -*- main -*-
# Please input experiment data
slope150_Exp = 23.4
slope1540_Exp = 40.4
heightAfpre = 1.077
# P4 and P6: 150 = 2; 1540 = 3.5; P3 150 = 3 and 1.5; 1540 = 4.5;
# P1 : 150 =  3, 1540 = 5.0; p5 : 150 = 2 , 1540 = 3; 
error_slope150 = 2.0
error_slope1540 = 5.0
error_height = 0.2

i = 1
f = 0
j = 0
k = 0
number_limitation = 20

jobname = 'job-'+ str(i)
E_o = 101.5  #Note: E_o is the input parameter; the young's modulus = E_o*2*2*(1+0.47)
Turgor = 0.66
maxh = 1.3
E_pectin = 6.2
E_i_ratio = E_pectin/E_o

runABAQUS(jobname,E_o,Turgor,E_i_ratio,maxh)
slope150,slope1540,maxheight,slope240,slope360,slope970,slope1240 = extractForcDisp(jobname)
diffHeight = abs(maxheight-heightAfpre)
diffslope150 = abs(slope150_Exp-slope150)
diffslope1540 = abs(slope1540_Exp-slope1540)

f11 = open('parameters.txt', 'w')
f11.write(jobname)
f11.write('f')
f11.write(str(f))
f11.write('j')
f11.write(str(j))
f11.write('k')
f11.write(str(k))
f11.write(" ")

f11.write('E_o')
f11.write(str(E_o))
f11.write(" ")  
f11.write('Turgor')
f11.write(str(Turgor))
f11.write(" ")  
f11.write('E_i_ratio')
f11.write(str(E_i_ratio))
f11.write(" ")
f11.write('height')
f11.write(str(maxheight))
f11.write(" ")  
f11.write('slope150')
f11.write(str(slope150))
f11.write(" ")  
f11.write('slope1540')
f11.write(str(slope1540))
f11.write(" ")  
f11.write('slope240')
f11.write(str(slope240))
f11.write(" ")  
f11.write('slope360')
f11.write(str(slope360))
f11.write(" ")  
f11.write('slope970')
f11.write(str(slope970))
f11.write(" ")  
f11.write('slope1240')
f11.write(str(slope1240))

f11.write("\n")

while diffHeight > error_height or diffslope150 > error_slope150 or diffslope1540 > error_slope1540:
    i = i+1
    f = f+1
    if i >= number_limitation :
        break
			
    if diffHeight > error_height :
        if maxheight > heightAfpre :
            E_o = E_o*(1+0.10)
        else :
            E_o = E_o*(1-0.10)

        jobname ='job-'+str (i)
        runABAQUS(jobname,E_o,Turgor,E_i_ratio,maxheight)
        slope150,slope1540,maxheight,slope240,slope360,slope970,slope1240 = extractForcDisp(jobname)
        diffHeight = abs(maxheight-heightAfpre)
        diffslope150 = abs(slope150_Exp-slope150)
        diffslope1540 = abs(slope1540_Exp-slope1540)

        f11.write(jobname)
        f11.write('f')
        f11.write(str(f))      
        f11.write('j')
        f11.write(str(j))
        f11.write('k')
        f11.write(str(k))
        f11.write(" ")

        f11.write('E_o')
        f11.write(str(E_o))
        f11.write(" ")  
        f11.write('Turgor')
        f11.write(str(Turgor))
        f11.write(" ")  
        f11.write('E_i_ratio')
        f11.write(str(E_i_ratio))
        f11.write(" ")    
        f11.write('height')
        f11.write(str(maxheight))
        f11.write(" ")  
        f11.write('slope150')
        f11.write(str(slope150))
        f11.write(" ")  
        f11.write('slope1540')
        f11.write(str(slope1540))
        f11.write(" ")
        f11.write('slope240')
        f11.write(str(slope240))
	f11.write(" ")  
	f11.write('slope360')
	f11.write(str(slope360))
	f11.write(" ")  
	f11.write('slope970')
	f11.write(str(slope970))
	f11.write(" ")  
	f11.write('slope1240')
	f11.write(str(slope1240))
    
        f11.write("\n")

    while diffslope150 > error_slope150 or diffslope1540 > error_slope1540:
        while diffslope1540 > error_slope1540:
            i = i+1
            k = k+1
            if i>=number_limitation:
                break

            if slope1540 > slope1540_Exp :
                Turgor = Turgor*(1-0.08)
            else :
                Turgor = Turgor*(1+0.08)
            
            jobname ='job-'+str (i) 
            runABAQUS(jobname,E_o,Turgor,E_i_ratio,maxheight)
            slope150,slope1540,maxheight,slope240,slope360,slope970,slope1240 = extractForcDisp(jobname)
            diffHeight = abs(maxheight-heightAfpre)
            diffslope150 = abs(slope150_Exp-slope150)
            diffslope1540 = abs(slope1540_Exp-slope1540)

            f11.write(jobname)              
            f11.write('f')
            f11.write(str(f))
            f11.write('j')
            f11.write(str(j))
            f11.write('k')
            f11.write(str(k))
            f11.write(" ")

            f11.write('E_o')
            f11.write(str(E_o))
            f11.write(" ")  
            f11.write('Turgor')
            f11.write(str(Turgor))
            f11.write(" ")  
            f11.write('E_i_ratio')
            f11.write(str(E_i_ratio))
            f11.write(" ")
            f11.write('height')
            f11.write(str(maxheight))
            f11.write(" ")  
            f11.write('slope150')
            f11.write(str(slope150))
            f11.write(" ")  
            f11.write('slope1540')
            f11.write(str(slope1540))
            f11.write(" ")  
            f11.write('slope240')
            f11.write(str(slope240))
            f11.write(" ")  
            f11.write('slope360')
            f11.write(str(slope360))
            f11.write(" ")  
            f11.write('slope970')
            f11.write(str(slope970))
            f11.write(" ")  
            f11.write('slope1240')
            f11.write(str(slope1240))

            f11.write("\n")
        while diffslope150 > error_slope150:
            i = i+1
            j = j+1
            if i >= number_limitation :
                break

            if slope150 > slope150_Exp :
                E_o = E_o*(1-0.1)
            else :
                E_o = E_o*(1+0.1)

            if E_o != 0.0 :
                E_i_ratio = E_pectin/E_o
                    
            jobname ='job-'+str (i)
            runABAQUS(jobname,E_o,Turgor,E_i_ratio,maxheight)
            slope150,slope1540,maxheight,slope240,slope360,slope970,slope1240 = extractForcDisp(jobname)
            diffHeight = abs(maxheight-heightAfpre)
            diffslope150 = abs(slope150_Exp-slope150)
            diffslope1540 = abs(slope1540_Exp-slope1540)

            f11.write(jobname)        
            f11.write('f')
            f11.write(str(f))              
            f11.write('j')
            f11.write(str(j))
            f11.write('k')
            f11.write(str(k))
            f11.write(" ")

            f11.write('E_o')
            f11.write(str(E_o))
            f11.write(" ")  
            f11.write('Turgor')
            f11.write(str(Turgor))
            f11.write(" ")  
            f11.write('E_i_ratio')
            f11.write(str(E_i_ratio))
            f11.write(" ")
            f11.write('height')
            f11.write(str(maxheight))
            f11.write(" ")  
            f11.write('slope150')
            f11.write(str(slope150))
            f11.write(" ")  
            f11.write('slope1540')
            f11.write(str(slope1540))
            f11.write(" ")  
            f11.write('slope240')
            f11.write(str(slope240))
            f11.write(" ")  
            f11.write('slope360')
            f11.write(str(slope360))
            f11.write(" ")  
            f11.write('slope970')
            f11.write(str(slope970))
            f11.write(" ")  
            f11.write('slope1240')
            f11.write(str(slope1240))

            f11.write("\n")

f11.close()
# -*- END -*-
